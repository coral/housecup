'use strict';

var Q = require('q');
var request = require('request');
var nodecg = null;

module.exports = function (extensionApi) {
	nodecg = extensionApi;


	nodecg.declareSyncedVar({
		name: 'setTest',
		initialVal: {
			question_id: 2,
			vote_id: 2,
			cat_id: 2
		},
		setter: function(newVal) {
			console.log(nodecg.variables.setTest);
		}
	});

};

