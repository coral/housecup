var panel = $bundle.filter('.settertest');
