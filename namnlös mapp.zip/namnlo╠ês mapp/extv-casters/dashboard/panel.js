var panel = $bundle.filter('.caster-names');
var preview = panel.find('.js-preview');
var program = panel.find('.js-program');

var inBtn = $('#extv-casters_in');
var outBtn = $('#extv-casters_out');
var pulseBtn = $('#extv-casters_pulse7');

inBtn.click(function () {
    nodecg.variables.isShowing = true;
    updateNames();
});
outBtn.click(function () { nodecg.variables.isShowing = false; });
pulseBtn.click(function () {
    nodecg.sendMessage('pulse', 7);
    updateNames();
});

function updateNames() {
    nodecg.variables.names = {
        left: preview.find('.left').val(),
        right: preview.find('.right').val()
    };
}

nodecg.declareSyncedVar({ variableName: 'names',
    initialVal: {},
    setter: function(newVal) {
        program.find('.left').val(newVal.left);
        program.find('.right').val(newVal.right);
    }
});

nodecg.declareSyncedVar({ variableName: 'isShowing',
    initialVal: false,
    setter: function(newVal) {
        inBtn.prop('disabled', newVal);
        pulseBtn.prop('disabled', newVal);
        outBtn.prop('disabled', !newVal);
    }
});

nodecg.declareSyncedVar({ variableName: 'isPulsing',
    initialVal: false,
    setter: function(newVal) {
        !nodecg.variables.isShowing
            ? outBtn.prop('disabled', true)
            : outBtn.prop('disabled', newVal)
    }
});