#toth-alert
A simple alert message with a single-button interface. The alert slides in, displays for 8 seconds, then slides out. Includes SFX.

### Credits
[Alex "Lange" Van Camp](http://alexvan.camp), lead programmer & designer of [toth-overlay](https://github.com/Langeh/toth-overlay), from which this package is taken
[Matt "bluee" McNamara](http://mattmcn.com/), adapted this package to NodeCG from it's previous toth-overlay implementation
[Anthony "Airon" Oetzmann](http://aironaudio.weebly.com/), sound designer
[Atmo](https://github.com/atmosfar), original designer of this alert package as a proof-of-concept for a NodeJS-based live graphics solution