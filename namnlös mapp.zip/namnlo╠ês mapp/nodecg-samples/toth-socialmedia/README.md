#toth-socialmedia
A display of Tip of the Hats social media links such as Twitter, Youtube, and the One Step Camp homepage. Includes SFX.

### Usage
Install to nodecg/packages/

### Credits
[Alex "Lange" Van Camp](http://alexvan.camp), lead programmer & designer of [toth-overlay](https://github.com/Langeh/toth-overlay), from which this package is taken
[Anthony "Airon" Oetzmann](http://aironaudio.weebly.com/), sound designer  