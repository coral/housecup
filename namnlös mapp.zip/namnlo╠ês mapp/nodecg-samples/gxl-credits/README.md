#gxl-credits
A fading credits display, with automatic scrolling for large groups and configurable display, fade in and fade out durations.

### Usage
Install to nodecg/bundles/  
Edit staff.json to suit your needs.  
You can also edit the file 'live', and refresh from the dashboard panel.  

### Logos
The logos shown in the [GXL outro](http://youtu.be/A3c2b6KRyHE?t=2m26s) were part of this bundle, but have been removed in the public release.  
However, you can look at the top 3 entries in staff.json, beginning with periods, and compare them with the img tags left in the view to see how it worked, and how you can add your own logos.

### Fonts
Futura Medium and Heavy are used in the view, but the fonts not included.  
You can either provide `FuturaStd-Heavy.otf` and `FuturaStd-Medium.otf` in `view/fonts/`, or use a different font and update the style accordingly.

### Credits
[Matthew "Bluee" McNamara](http://mattmcn.com), developer, co-designer  
Alex "Dashner" Pylyshyn, co-designer
