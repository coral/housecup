#toth-lowerthird
A lowerthird with SFX. Title and body can be set via the dashboard. Can be triggered to show and hide manually or on a timer.

### Usage
Install to nodecg/packages/

### Credits
[Alex "Lange" Van Camp](http://alexvan.camp), lead programmer & designer of [toth-overlay](https://github.com/Langeh/toth-overlay), from which this package is taken
[Anthony "Airon" Oetzmann](http://aironaudio.weebly.com/), sound designer  