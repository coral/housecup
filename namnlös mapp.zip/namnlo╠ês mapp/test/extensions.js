'use strict';

var log = require('../../lib/logger')('test');

module.exports = function(nodecg) {
    try {
        var osc = require('./extensions/osc')(nodecg);
    } catch (e) {
        log.error("Failed to load osc lib:", e.stack);
        process.exit(1);
    }
};
