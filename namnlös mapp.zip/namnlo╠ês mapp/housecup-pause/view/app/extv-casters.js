$(document).on('ncgReady', function () {
    // Needed to make sure the first "show" action behaves as expected
    // Bit of a hack, but it works
    var isInitialized = false;

    // Set up sounds
    $.ionSound({
        sounds: [           // set needed sounds names
            "casters_in",
            "casters_out"
        ],
        path: "/view/extv-casters/sounds/",       // set path to sounds
        multiPlay: true,    // can play multiple sounds at once
        volume: "0.3"      // not so loud please
    });

    nodecg.declareSyncedVar({ variableName: 'isShowing',
        initialVal: false,
        setter: function(newVal) {
            newVal
                ? castersIn()
                : castersOut();

            isInitialized = true;
        }
    });

    nodecg.declareSyncedVar({ variableName: 'names',
        initialVal: {},
        setter: function(newVal) {
            $('#leftCaster').html(newVal.left);
            $('#rightCaster').html(newVal.right);
            textFit($('.caster'), {detectMultiLine: false, maxFontSize: 40, alignVert: true, alignHoriz: true});
        }
    });

    // Add listener to transition from "in" to "loop"
    $('#circleIn').on('ended', function () {
        play($('#circleLoop'));
        sleep(16);
        stop($('#circleIn'));
    });

    function castersIn() {
        stop($('#circleOut')); // Stop this here to make sure it seeks back to the start, prevents flicker
        play($('#circleIn'));

        setTimeout(function(){
            $.ionSound.play('casters_in');
        }, 175);

        //create a new TimelineLite instance
        var tl = new TimelineLite({paused: true});

        // Animate top panels out from center after logo in video plays
        tl.to($('#leftPanel'), 0.6, {x: "138px", ease: Quad.easeOut}, 1);
        tl.to($('#rightPanel'), 0.6, {x: "-2px", ease: Quad.easeOut}, 1);

        tl.play();
    }

    function castersOut() {
        if (!isInitialized)
            return;

        // Wait until the current loop finishes before playing out anim
        $('#circleLoop').on('seeking', function () {
            play($('#circleOut'));
            sleep(16);
            stop($('#circleLoop'));

            setTimeout(function(){
                $.ionSound.play('casters_out');
            }, 408);

            //create a new TimelineLite instance
            var tl = new TimelineLite({paused: true});

            // Animate top panels in, behind the logo
            tl.to($('#leftPanel'), 0.6, {x: "590px", ease: Quad.easeIn}, 0.4);
            tl.to($('#rightPanel'), 0.6, {x: "-450px", ease: Quad.easeIn}, 0.4);

            tl.play();

            //Remove our loop event hook
            $('#circleLoop').off('seeking');
        });
    }

    function play(vid) {
        vid.get(0).play();
        vid.css('display', 'block');
    }

    function stop(vid) {
        vid.css('display', '');
        vid.get(0).pause();
        vid.get(0).currentTime = 0;
    }

    function sleep(milliseconds) {
        var start = new Date().getTime();
        for (var i = 0; i < 1e7; i++) {
            if ((new Date().getTime() - start) > milliseconds) {
                break;
            }
        }
    }
});