var panel = $bundle.filter('.player-stats');
var inBtn = $('#extv-player_in');
var outBtn = $('#extv-player_out');
var takeBtn = $('#extv-player_take');

var stat1 = panel.find('.stat:nth-of-type(1)');
var stat2 = panel.find('.stat:nth-of-type(2)');
var stat3 = panel.find('.stat:nth-of-type(3)');

inBtn.click(function () { nodecg.variables.isShowing = true; });
outBtn.click(function () { nodecg.variables.isShowing = false; });
takeBtn.click(function () { nodecg.variables.stats = updateData(); });

nodecg.declareSyncedVar({ variableName: 'isShowing',
    initialVal: false,
    setter: function(newVal) {
        inBtn.prop('disabled', newVal);
        outBtn.prop('disabled', !newVal);
    }
});

nodecg.declareSyncedVar({ variableName: 'stats', initialVal: {} });

function updateData() {
    return {
        name: $('#extv-player_name').val(),
        stat1: {
            heading: stat1.find('.stat-name input').val(),
            value: stat1.find('.stat-value input').val()
        },
        stat2: {
            heading: stat2.find('.stat-name input').val(),
            value: stat2.find('.stat-value input').val()
        },
        stat3: {
            heading: stat3.find('.stat-name input').val(),
            value: stat3.find('.stat-value input').val()
        },
        label: $('#extv-player_label').val(),
        playerPic: $('#extv-player_picture > label > input[type="radio"]:checked').val()
    };
}

var images = [
    "/view/extv-player/images/players/scout1.png",
    "/view/extv-player/images/players/scout2.png",
    "/view/extv-player/images/players/scout3.png",
    "/view/extv-player/images/players/scout4.png",
    "/view/extv-player/images/players/soldier1.png",
    "/view/extv-player/images/players/soldier2.png",
    "/view/extv-player/images/players/soldier3.png",
    "/view/extv-player/images/players/soldier4.png",
    "/view/extv-player/images/players/medic1.png",
    "/view/extv-player/images/players/medic2.png",
    "/view/extv-player/images/players/demo1.png",
    "/view/extv-player/images/players/demo2.png",
    "/view/extv-player/images/players/sniper.png"
];

// TODO: make this use a document fragment
$.each(images, function (index, value) {
    var html =
        '<label>' +
        '<input type="radio" name="pic" value="' + value + '"/>' +
        '<div class="pic" style=\'background: url("' + value + '")\'></div>' +
        '</label>';

    $('#extv-player_picture').append(html);
});