$(document).on('ncgReady', function () {
    // Needed to make sure the first "show" action behaves as expected
    // Bit of a hack, but it works
    var isInitialized = false;

    // Set up sounds
    $.ionSound({
        sounds: [           // set needed sounds names
            "player_in",
            "player_out"
        ],
        path: "/view/extv-player/sounds/",       // set path to sounds
        multiPlay: true,    // can play multiple sounds at once
        volume: "0.3"      // not so loud please
    });

    nodecg.declareSyncedVar({ variableName: 'isShowing',
        initialVal: false,
        setter: function(newVal) {
            newVal
                ? playerIn()
                : playerOut();

            isInitialized = true;
        }
    });

    nodecg.declareSyncedVar({ variableName: 'stats',
        initialVal: {},
        setter: playerUpdate
    });

    $('#circleIn').on('ended', function () {
        play($('#circleLoop'));
        sleep(40);
        stop($('#circleIn'));
    });

    function playerIn() {
        stop($('#circleOut')); // Stop this here to make sure it seeks back to the start, prevents flicker
        play($('#circleIn'));

        setTimeout(function(){
            $.ionSound.play('player_in');
        }, 408);

        //create a new TimelineLite instance
        var tl = new TimelineLite({delay: 1.5, paused: true});

        //append to() tweens for the plate images, showing the subplate only after the main plate has finished animating
        tl.to($('.mainPlate'), 0.9, {transform: "translateX(0px)", ease: Quad.easeOut});
        tl.to($('#playerPic'), 0.6, {transform: "translateY(0px)", ease: Quad.easeOut}, "0");
        tl.set($('.subPlate'), {visibility: 'visible'});
        tl.to($('.subPlate'), 0.4, {transform: "translateY(0px)", ease: Quad.easeOut});

        tl.play();
    }

    function playerUpdate(data) {
        $('.name').html(data.name);
        textFit($('.name'));
        $('th.stat1').html(data.stat1.heading);
        textFit($('th.stat1'), {detectMultiLine: false, maxFontSize: 20});
        $('td.stat1').html(data.stat1.value);
        textFit($('td.stat1'), {detectMultiLine: false, maxFontSize: 30});
        $('th.stat2').html(data.stat2.heading);
        textFit($('th.stat2'), {detectMultiLine: false, maxFontSize: 20});
        $('td.stat2').html(data.stat2.value);
        textFit($('td.stat2'), {detectMultiLine: false, maxFontSize: 30});
        $('th.stat3').html(data.stat3.heading);
        textFit($('th.stat3'), {detectMultiLine: false, maxFontSize: 20});
        $('td.stat3').html(data.stat3.value);
        textFit($('td.stat3'), {detectMultiLine: false, maxFontSize: 30});
        $('#subText').html(data.label);
        textFit($('#subText'), {detectMultiLine: false, maxFontSize: 24, alignVert: true});
        $('#playerPic').css('background', "url('" + data.playerPic + "')");
    }

    function playerOut() {
        if (!isInitialized)
            return;

        // Wait until the current loop finishes before playing out anim
        $('#circleLoop').on('seeking', function () {
            play($('#circleOut'));
            sleep(16);
            stop($('#circleLoop'));

            setTimeout(function(){
                $.ionSound.play('player_out');
            }, 1283);


            //create a new TimelineLite instance
            var tl = new TimelineLite({delay: 2, paused: true});

            //append to() tweens for the plate images, showing the subplate only after the main plate has finished animating
            tl.to($('.subPlate'), 0.4, {transform: "translateY(-34px)", ease: Quad.easeIn});
            tl.set($('.subPlate'), {visibility: 'hidden'});
            tl.to($('.mainPlate'), 0.9, {transform: "translateX(-800px)", ease: Quad.easeIn});
            tl.to($('#playerPic'), 0.6, {transform: "translateY(150px)", ease: Quad.easeIn}, "0.4");

            tl.play();

            //Remove our loop event hook
            $('#circleLoop').off('seeking');
        });
    }

    function play(vid) {
        vid.get(0).play();
        vid.css('display', 'block');
    }

    function stop(vid) {
        vid.css('display', '');
        vid.get(0).pause();
        vid.get(0).currentTime = 0;
    }

    function sleep(milliseconds) {
        var start = new Date().getTime();
        for (var i = 0; i < 1e7; i++) {
            if ((new Date().getTime() - start) > milliseconds) {
                break;
            }
        }
    }
});