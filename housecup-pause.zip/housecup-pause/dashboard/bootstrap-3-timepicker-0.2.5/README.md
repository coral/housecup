Timepicker for Twitter Bootstrap 3
fork of https://github.com/jdewit/bootstrap-timepicker
=====================