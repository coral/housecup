var panel = $bundle.filter('.pause-panel');
var preview = panel.find('.js-preview');
var program = panel.find('.js-program');

var start = $('#housecup-countdown_start');
var stop = $('#housecup-countdown_stop');
var end = $('#housecup-countdown_end');

var large = $('#housecup-countdown_large');
var small = $('#housecup-countdown_small');
var hide = $('#housecup-countdown_hide');
var modify = $('.housecup-size_modify');

var datetimepickerz = panel.find('#datetimepicker12');


modify.click(function () {
    nodecg.variables.size = $(this).data("value");
});

start.click(function () {
    nodecg.variables.animate = true;
});

stop.click(function () {
    nodecg.variables.animate = false;
});

$('#countdown-to').datetimepicker({
                inline: true,
                sideBySide: false,
                format: "H HH m mm"
            });

/*
inBtn.click(function () {
    nodecg.variables.isShowing = true;
    updateNames();
});
outBtn.click(function () { nodecg.variables.isShowing = false; });
pulseBtn.click(function () {
    nodecg.sendMessage('pulse', 7);
    updateNames();
});
*/


function updateNames() {
    nodecg.variables.names = {
        left: preview.find('.left').val(),
        right: preview.find('.right').val()
    };
}

nodecg.declareSyncedVar({ variableName: 'size',
    initialVal: "hide",
    setter: function(newVal) {
        console.log(newVal);
    }
});

nodecg.declareSyncedVar({ variableName: 'animate',
    initialVal: true,
    setter: function(newVal) {
        console.log(newVal);
    }
});

/*
nodecg.declareSyncedVar({ variableName: 'names',
    initialVal: {},
    setter: function(newVal) {
        program.find('.left').val(newVal.left);
        program.find('.right').val(newVal.right);
    }
});

nodecg.declareSyncedVar({ variableName: 'isShowing',
    initialVal: false,
    setter: function(newVal) {
        inBtn.prop('disabled', newVal);
        pulseBtn.prop('disabled', newVal);
        outBtn.prop('disabled', !newVal);
    }
});

nodecg.declareSyncedVar({ variableName: 'isPulsing',
    initialVal: false,
    setter: function(newVal) {
        !nodecg.variables.isShowing
            ? outBtn.prop('disabled', true)
            : outBtn.prop('disabled', newVal)
    }
});*/
